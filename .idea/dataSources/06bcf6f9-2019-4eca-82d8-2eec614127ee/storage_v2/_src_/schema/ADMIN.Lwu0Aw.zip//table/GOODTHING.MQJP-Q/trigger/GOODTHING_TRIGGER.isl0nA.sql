create trigger GOODTHING_TRIGGER
    before insert
    on GOODTHING
    for each row
begin
     select goodthing_seq.nextval into :new.id from dual;
   end;
/

